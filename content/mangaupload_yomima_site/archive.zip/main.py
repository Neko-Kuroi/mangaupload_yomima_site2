import os
import shutil
import zipfile
import re
import uuid
import json
import logging
import threading
import time
from typing import List, Generator
from pathlib import Path
from datetime import datetime, timedelta, UTC

from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Request, status
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr
from passlib.context import CryptContext
from jose import jwt, JWTError
from PIL import Image
from sqlalchemy import create_engine, Column, Integer, String, Boolean, DateTime
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from google.colab import output

# --- ログ設定 ---
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# --- ディレクトリ準備 ---
STATIC_DIR = Path("/content/static")
STATIC_DIR.mkdir(exist_ok=True)
TMP_DIR = Path("./storage/tmp")
FINAL_ZIP_DIR = Path("./storage/zips")
TMP_DIR.mkdir(parents=True, exist_ok=True)
FINAL_ZIP_DIR.mkdir(parents=True, exist_ok=True)

# --- 1. 設定 & データベース ---
SECRET_KEY = "MANGA_PLATFORM_SUPER_SECRET_KEY"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

DATABASE_URL = "sqlite:///:memory:"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    is_active = Column(Boolean, default=True)

Base.metadata.create_all(bind=engine)

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- 2. 暗号化 & 認証ロジック ---
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/token")

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="認証トークンが無効です")
    except JWTError:
        raise HTTPException(status_code=401, detail="トークンの期限切れ、または不正です")
    user = db.query(User).filter(User.id == int(user_id)).first()
    if not user:
        raise HTTPException(status_code=401, detail="ユーザーが見つかりません")
    return user

# --- 3. Pydantic スキーマ ---
class UserRegister(BaseModel):
    username: str
    email: EmailStr
    password: str

class EpisodePublishSettings(BaseModel):
    status: str
    access_level: str
    price: int = 0

# --- 4. FastAPI アプリケーション定義 ---
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def natural_keys(text: str):
    return [int(c) if c.isdigit() else c.lower() for c in re.split(r'(\d+)', text)]

# --- 5. API エンドポイント ---

# 【認証】新規会員登録
@app.post("/api/auth/signup")
async def signup(user_data: UserRegister, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(400, "登録済みのメールアドレスです")
    if db.query(User).filter(User.username == user_data.username).first():
        raise HTTPException(400, "使用済みのユーザー名です")
    hashed_pw = pwd_context.hash(user_data.password)
    new_user = User(username=user_data.username, email=user_data.email, hashed_password=hashed_pw)
    db.add(new_user)
    db.commit()
    return {"message": "ユーザー登録が完了しました。ログインしてください。"}

# 【認証】ログイン (トークン発行)
@app.post("/api/auth/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == form_data.username).first()
    if not user or not pwd_context.verify(form_data.password, user.hashed_password):
        raise HTTPException(401, "ユーザー名またはパスワードが正しくありません")
    access_token = jwt.encode(
        {"sub": str(user.id), "exp": datetime.now(UTC) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)},
        SECRET_KEY, algorithm=ALGORITHM
    )
    return {"access_token": access_token, "token_type": "bearer", "username": user.username}

# 【作者機能】マンガ原稿アップロード
@app.post("/api/author/titles/{title_id}/episodes/{episode_id}/upload-and-zip")
async def upload_manga(
    title_id: int, episode_id: int,
    files: List[UploadFile] = File(...),
    current_user: User = Depends(get_current_user)
):
    user_dir = FINAL_ZIP_DIR / f"user_{current_user.id}" / f"title_{title_id}"
    user_dir.mkdir(parents=True, exist_ok=True)
    final_zip_path = user_dir / f"episode_{episode_id}.cbz"

    work_dir = TMP_DIR / f"u{current_user.id}_t{title_id}_e{episode_id}_{uuid.uuid4().hex[:6]}"
    work_dir.mkdir(parents=True, exist_ok=True)

    try:
        files.sort(key=lambda x: natural_keys(x.filename))
        saved_pages = []
        for index, file in enumerate(files):
            suffix = Path(file.filename).suffix.lower()
            if suffix not in {".jpg", ".jpeg", ".png", ".webp"}:
                continue
            raw_path = work_dir / f"raw_{file.filename}"
            with open(raw_path, "wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
            target_path = work_dir / f"page_{index+1:04d}.png"
            with Image.open(raw_path) as img:
                img.convert("RGB").save(target_path, "PNG", optimize=True)
            saved_pages.append(target_path)
            raw_path.unlink()

        with zipfile.ZipFile(final_zip_path, 'w', zipfile.ZIP_DEFLATED) as comic_zip:
            for p in saved_pages:
                comic_zip.write(p, arcname=p.name)

        return {"status": "success", "page_count": len(saved_pages), "author": current_user.username}
    finally:
        if work_dir.exists():
            shutil.rmtree(work_dir)

# 【作者機能】公開設定の保存
@app.patch("/api/author/titles/{title_id}/episodes/{episode_id}/settings")
async def update_settings(
    title_id: int, episode_id: int,
    settings: EpisodePublishSettings,
    current_user: User = Depends(get_current_user)
):
    user_dir = FINAL_ZIP_DIR / f"user_{current_user.id}" / f"title_{title_id}"
    user_dir.mkdir(parents=True, exist_ok=True)
    meta_data = settings.dict()
    meta_data["author_name"] = current_user.username
    meta_data["author_id"] = current_user.id
    meta_data["title_id"] = title_id
    meta_data["episode_id"] = episode_id
    with open(user_dir / f"episode_{episode_id}_settings.json", "w") as f:
        json.dump(meta_data, f, indent=4)
    return {"status": "success"}

# 【読者機能】公開されているマンガの一覧（旧エンドポイント、後方互換）
@app.get("/api/public/search")
async def search_published_manga():
    published_list = []
    for settings_path in FINAL_ZIP_DIR.glob("user_*/title_*/episode_*_settings.json"):
        try:
            with open(settings_path, "r") as f:
                meta = json.load(f)
            if meta.get("status") == "published":
                published_list.append(meta)
        except Exception:
            continue
    return published_list

# 【CBZ配信 - 公開用】認証不要で公開済み作品を配信する
@app.get("/api/public/cbz/{user_id}/{title_id}/{episode_id}.cbz")
async def serve_public_cbz(user_id: int, title_id: int, episode_id: int):
    """
    認証不要。published なエピソードだけ配信する。
    ビューワーはこの URL を manga_url として使う。
    """
    settings_path = (
        FINAL_ZIP_DIR
        / f"user_{user_id}"
        / f"title_{title_id}"
        / f"episode_{episode_id}_settings.json"
    )
    if not settings_path.exists():
        raise HTTPException(status_code=404, detail="作品が見つかりません")

    with open(settings_path, "r") as f:
        meta = json.load(f)

    if meta.get("status") != "published":
        raise HTTPException(status_code=403, detail="この作品は非公開です")

    cbz_path = FINAL_ZIP_DIR / f"user_{user_id}" / f"title_{title_id}" / f"episode_{episode_id}.cbz"
    if not cbz_path.exists():
        raise HTTPException(status_code=404, detail="CBZファイルが見つかりません")

    return FileResponse(
        path=str(cbz_path),
        media_type="application/zip",
        filename=f"title{title_id}_ep{episode_id}.cbz",
        headers={"Cache-Control": "public, max-age=3600"},
    )

# 【CBZ配信 - 認証付き】作者が自分の作品を取得する
@app.get("/api/cbz/{user_id}/{title_id}/{episode_id}.cbz")
async def serve_cbz(
    user_id: int, title_id: int, episode_id: int,
    current_user: User = Depends(get_current_user),
):
    cbz_path = FINAL_ZIP_DIR / f"user_{user_id}" / f"title_{title_id}" / f"episode_{episode_id}.cbz"
    if not cbz_path.exists():
        raise HTTPException(status_code=404, detail="CBZファイルが見つかりません")
    return FileResponse(
        path=str(cbz_path),
        media_type="application/zip",
        filename=f"title{title_id}_ep{episode_id}.cbz",
        headers={"Cache-Control": "no-store"},
    )

# 【公開カタログ】cbz_url 付きの公開作品一覧（ビューワーが叩く）
@app.get("/api/public/catalog")
async def public_catalog(request: Request):
    base_url = str(request.base_url).rstrip("/")
    published_list = []
    for settings_path in FINAL_ZIP_DIR.glob("user_*/title_*/episode_*_settings.json"):
        try:
            with open(settings_path, "r") as f:
                meta = json.load(f)
            if meta.get("status") != "published":
                continue
            uid = meta["author_id"]
            tid = meta["title_id"]
            eid = meta["episode_id"]
            meta["cbz_url"] = f"{base_url}/api/public/cbz/{uid}/{tid}/{eid}.cbz"
            published_list.append(meta)
        except Exception:
            continue
    return published_list

# --- 6. 画面配信 ---
@app.get("/", response_class=HTMLResponse)
async def read_root():
    with open(STATIC_DIR / "index.html", "r", encoding="utf-8") as f:
        return f.read()

# --- 7. HTML UI の書き出し ---
index_html_content = '''
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>次世代マンガプラットフォーム（デモ）</title>
  <style>
    body { font-family: sans-serif; margin: 0; padding: 0; background: #f3f4f6; color: #333; }
    nav { background: #1e293b; padding: 15px; text-align: center; }
    nav a { color: white; margin: 0 15px; text-decoration: none; font-weight: bold; cursor: pointer; }
    .container { max-width: 800px; margin: 30px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
    .page { display: none; }
    .active { display: block; }
    .form-group { margin-bottom: 15px; }
    .form-group label { display: block; font-weight: bold; margin-bottom: 5px; }
    .form-group input, .form-group select { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
    button { background: #2563eb; color: white; border: none; padding: 10px 20px; font-size: 16px; border-radius: 4px; cursor: pointer; width: 100%; font-weight: bold; }
    button:disabled { background: #9ca3af; }
    #drop-zone { border: 3px dashed #cbd5e1; padding: 40px; text-align: center; border-radius: 6px; cursor: pointer; background: #f8fafc; }
    .manga-card { border: 1px solid #e2e8f0; padding: 15px; margin-bottom: 10px; border-radius: 6px; background: #fafafa; }
    .badge { display: inline-block; padding: 3px 8px; font-size: 12px; font-weight: bold; border-radius: 9999px; color: white; }
    .badge-free { background: #10b981; } .badge-paid { background: #f59e0b; }
    #login-status { color: #38bdf8; font-size: 14px; margin-top: 5px; display: block; }
  </style>
</head>
<body>

  <nav>
    <a onclick="showPage('search-page'); loadPublishedManga();">🔍 公開マンガを探す</a>
    <a onclick="showPage('upload-page')">📤 投稿（マイページ）</a>
    <a onclick="showPage('auth-page')">🔐 ログイン/登録</a>
    <span id="login-status">状態: 未ログイン</span>
  </nav>

  <div id="search-page" class="container page active">
    <h2>📖 公開中のエピソード一覧</h2>
    <p style="color:#666;">ステータスが「公開(published)」になっている作品のみ表示されます。</p>
    <button onclick="loadPublishedManga()" style="background:#475569; margin-bottom:20px;">🔄 一覧を更新する</button>
    <div id="manga-list"></div>
  </div>

  <div id="upload-page" class="container page">
    <h2>投稿マイページ (原稿アップローダー)</h2>
    <p style="color:red;font-size:14px;" id="upload-warn">⚠️ 先にログインしてください。</p>
    <div class="form-group">
      <label>作品ID: <input type="number" id="title_id" value="1"></label>
    </div>
    <div class="form-group">
      <label>エピソードID: <input type="number" id="episode_id" value="1"></label>
    </div>
    <div class="form-group">
      <label>公開状況:
        <select id="status_select">
          <option value="draft">下書き (検索非表示)</option>
          <option value="published">公開 (誰でも検索可能)</option>
        </select>
      </label>
    </div>
    <div class="form-group">
      <label>アクセス権限:
        <select id="access_level_select">
          <option value="public">無料公開</option>
          <option value="premium">有料会員限定</option>
        </select>
      </label>
    </div>
    <div id="drop-zone">
      <p>ここに原稿画像（複数可）をドロップ、またはクリックして選択</p>
      <input type="file" id="file-input" multiple accept="image/*" style="display:none;">
    </div>
    <div id="file-list" style="margin:10px 0;font-size:14px;color:#555;"></div>
    <button id="upload-btn" onclick="uploadMangaAndSettings()" disabled style="margin-top:15px;">原稿をアップロードして設定を適用</button>
    <p id="upload-status" style="font-weight:bold;margin-top:10px;"></p>
  </div>

  <div id="auth-page" class="container page">
    <h2>🔐 アカウント管理</h2>
    <div style="border-bottom:1px solid #ccc;margin-bottom:20px;padding-bottom:20px;">
      <h3>ログイン</h3>
      <div class="form-group"><label>ユーザー名: <input type="text" id="login-user" value="author_one"></label></div>
      <div class="form-group"><label>パスワード: <input type="password" id="login-pass" value="password123"></label></div>
      <button onclick="handleLogin()">ログインする</button>
    </div>
    <div>
      <h3>新規アカウント作成</h3>
      <div class="form-group"><label>ユーザー名: <input type="text" id="reg-user" placeholder="例: taro_manga"></label></div>
      <div class="form-group"><label>メールアドレス: <input type="email" id="reg-email" placeholder="test@example.com"></label></div>
      <div class="form-group"><label>パスワード: <input type="password" id="reg-pass" placeholder="8文字以上"></label></div>
      <button onclick="handleSignup()" style="background:#10b981;">アカウントを新規登録</button>
    </div>
  </div>

  <script>
    let token = "";
    let selectedFiles = [];

    function showPage(pageId) {
      document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
      document.getElementById(pageId).classList.add('active');
    }

    async function handleLogin() {
      const formData = new FormData();
      formData.append("username", document.getElementById("login-user").value);
      formData.append("password", document.getElementById("login-pass").value);
      try {
        const res = await fetch("/api/auth/token", { method: "POST", body: formData });
        if (!res.ok) throw new Error("ログインに失敗しました");
        const data = await res.json();
        token = data.access_token;
        document.getElementById("login-status").textContent = `状態: 👤 ${data.username} としてログイン中`;
        document.getElementById("upload-warn").style.display = "none";
        alert("ログイン成功！");
        showPage('upload-page');
      } catch (e) { alert(e.message); }
    }

    async function handleSignup() {
      const payload = {
        username: document.getElementById("reg-user").value,
        email: document.getElementById("reg-email").value,
        password: document.getElementById("reg-pass").value
      };
      try {
        const res = await fetch("/api/auth/signup", {
          method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || "登録エラー");
        alert(data.message);
      } catch (e) { alert(e.message); }
    }

    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    dropZone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', (e) => handleFiles(e.target.files));
    dropZone.addEventListener('dragover', (e) => { e.preventDefault(); dropZone.style.background = "#e2e8f0"; });
    dropZone.addEventListener('dragleave', () => dropZone.style.background = "#f8fafc");
    dropZone.addEventListener('drop', (e) => { e.preventDefault(); dropZone.style.background = "#f8fafc"; handleFiles(e.dataTransfer.files); });

    function handleFiles(files) {
      selectedFiles = Array.from(files).filter(f => f.type.startsWith('image/'));
      document.getElementById('file-list').textContent = `${selectedFiles.length} 枚の画像を選択中`;
      document.getElementById('upload-btn').disabled = selectedFiles.length === 0;
    }

    async function uploadMangaAndSettings() {
      if (!token) { alert("ログインが確認できません。"); showPage('auth-page'); return; }
      const tId = document.getElementById('title_id').value;
      const eId = document.getElementById('episode_id').value;
      const statusText = document.getElementById('upload-status');
      statusText.style.color = "blue";
      statusText.textContent = "⌛ 1/2: 原稿を送信・圧縮中...";
      try {
        const formData = new FormData();
        selectedFiles.forEach(f => formData.append('files', f));
        const upRes = await fetch(`/api/author/titles/${tId}/episodes/${eId}/upload-and-zip`, {
          method: 'POST', headers: {"Authorization": `Bearer ${token}`}, body: formData
        });
        if (!upRes.ok) throw new Error("原稿のアップロードに失敗しました");
        statusText.textContent = "⌛ 2/2: 公開設定を保存中...";
        const setRes = await fetch(`/api/author/titles/${tId}/episodes/${eId}/settings`, {
          method: 'PATCH',
          headers: {'Content-Type': 'application/json', "Authorization": `Bearer ${token}`},
          body: JSON.stringify({
            status: document.getElementById('status_select').value,
            access_level: document.getElementById('access_level_select').value,
            price: 0
          })
        });
        if (!setRes.ok) throw new Error("公開設定の保存に失敗しました");
        statusText.style.color = "green";
        statusText.textContent = "✅ 成功！";
        selectedFiles = [];
        document.getElementById('file-list').textContent = "";
      } catch(e) {
        statusText.style.color = "red";
        statusText.textContent = "❌ エラー: " + e.message;
      }
    }

    async function loadPublishedManga() {
      const listDiv = document.getElementById("manga-list");
      listDiv.innerHTML = "読み込み中...";
      try {
        const res = await fetch("/api/public/catalog");
        const items = await res.json();
        if (items.length === 0) {
          listDiv.innerHTML = "<p style='color:#888;'>公開中の作品はありません。</p>";
          return;
        }
        listDiv.innerHTML = items.map(m => `
          <div class="manga-card">
            <h3>📖 作品ID: ${m.title_id} / エピソード: ${m.episode_id}</h3>
            <p>👤 投稿者: <strong>${m.author_name}</strong></p>
            <span class="badge ${m.access_level === 'public' ? 'badge-free' : 'badge-paid'}">
              ${m.access_level === 'public' ? '無料' : 'PREMIUM'}
            </span>
          </div>
        `).join('');
      } catch (e) { listDiv.innerHTML = "読み込みエラーが発生しました"; }
    }

    loadPublishedManga();
  </script>
</body>
</html>
'''

with open(STATIC_DIR / "index.html", "w", encoding="utf-8") as f:
    f.write(index_html_content)

# --- 8. サーバー起動 ---
def run_fastapi():
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="warning")

threading.Thread(target=run_fastapi, daemon=True).start()
time.sleep(2)

colab_url = output.serve_kernel_port_as_window(8000)
print(f"\n✨ プラットフォームが起動しました")
print(f"🔗 {colab_url}")
