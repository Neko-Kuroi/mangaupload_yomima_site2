"""
main.py - FastAPI router (thin glue layer)
"""

import asyncio
import concurrent.futures
import hashlib
import os
import httpx
from contextlib import asynccontextmanager
from typing import Annotated, Optional

import urllib.parse
from fastapi import FastAPI, Form, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

import manga as mg

# ---------------------------------------------------------------------------
# 絶対パス
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR    = os.path.join(BASE_DIR, "static")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")

# プラットフォームのベースURL（環境変数で上書き可能）
PLATFORM_BASE_URL = os.environ.get("PLATFORM_BASE_URL", "http://localhost:8000")

_executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)
_thumb_executor = concurrent.futures.ThreadPoolExecutor(max_workers=2)


@asynccontextmanager
async def lifespan(app: FastAPI):
    mg.manage_cache_size()
    mg.cleanup_old_cache()
    yield
    _executor.shutdown(wait=False)
    _thumb_executor.shutdown(wait=False)


app = FastAPI(title="Manga Reader", lifespan=lifespan)
templates = Jinja2Templates(directory=TEMPLATES_DIR)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


# ---------------------------------------------------------------------------
# List screen  GET /
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def index(
    request: Request,
    share: Optional[str] = Query(default=None),
):
    manga_list: list[dict] = []
    import_message: Optional[str] = None

    if share:
        manga_list, err = mg.decode_manga_list(share)
        if err:
            import_message = err

    return templates.TemplateResponse(request, "list.html", {
        "request": request,
        "manga_list": manga_list,
        "share_param": share or "",
        "import_message": import_message,
        "max_count": mg.MAX_MANGA_COUNT,
    })


# ---------------------------------------------------------------------------
# Public catalog screen  GET /public
# ---------------------------------------------------------------------------

@app.get("/public", response_class=HTMLResponse)
async def public_catalog(request: Request):
    """
    プラットフォームから公開済み作品一覧を取得して表示する。
    """
    catalog = []
    error_msg = None

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"{PLATFORM_BASE_URL}/api/public/catalog")
            resp.raise_for_status()
            catalog = resp.json()
    except Exception as e:
        error_msg = f"カタログの取得に失敗しました: {e}"

    return templates.TemplateResponse(request, "public.html", {
        "request": request,
        "catalog": catalog,
        "error_msg": error_msg,
        "platform_url": PLATFORM_BASE_URL,
    })


# ---------------------------------------------------------------------------
# Add manga  POST /manga/add
# ---------------------------------------------------------------------------

@app.post("/manga/add", response_class=HTMLResponse)
async def manga_add(
    request: Request,
    url: Annotated[str, Form()],
    title: Annotated[str, Form()] = "",
    share: Annotated[str, Form()] = "",
):
    manga_list, _ = mg.decode_manga_list(share) if share else ([], "")
    error: Optional[str] = None

    if not mg.validate_manga_url(url):
        error = "URLは .zip / .cbz / .rar / .cbr である必要があります"
    elif len(manga_list) >= mg.MAX_MANGA_COUNT:
        error = f"最大 {mg.MAX_MANGA_COUNT} 件まで登録できます"
    elif url in {m['url'] for m in manga_list}:
        error = "このURLはすでに追加されています"
    else:
        manga_list.append(mg.build_manga_entry(url, title))

    new_share = mg.encode_manga_list(manga_list) if manga_list else ""

    return templates.TemplateResponse(request, "partials/manga_list.html", {
        "request": request,
        "manga_list": manga_list,
        "share_param": new_share,
        "error": error,
        "max_count": mg.MAX_MANGA_COUNT,
    }, headers={"HX-Push-Url": f"/?share={new_share}" if new_share else "/"})


# ---------------------------------------------------------------------------
# Remove manga  POST /manga/remove
# ---------------------------------------------------------------------------

@app.post("/manga/remove", response_class=HTMLResponse)
async def manga_remove(
    request: Request,
    url: Annotated[str, Form()],
    share: Annotated[str, Form()] = "",
):
    manga_list, _ = mg.decode_manga_list(share) if share else ([], "")
    manga_list = [m for m in manga_list if m['url'] != url]
    new_share = mg.encode_manga_list(manga_list) if manga_list else ""

    return templates.TemplateResponse(request, "partials/manga_list.html", {
        "request": request,
        "manga_list": manga_list,
        "share_param": new_share,
        "error": None,
        "max_count": mg.MAX_MANGA_COUNT,
    }, headers={"HX-Push-Url": f"/?share={new_share}" if new_share else "/"})


# ---------------------------------------------------------------------------
# Reader screen  GET /reader
# ---------------------------------------------------------------------------

@app.get("/reader", response_class=HTMLResponse)
async def reader(
    request: Request,
    url: str = Query(...),
    share: str = Query(default=""),
    webhook1: str = Query(default=""),
    webhook2: str = Query(default=""),
):
    if not mg.validate_manga_url(url):
        raise HTTPException(status_code=400, detail="無効なURL")

    manga_list, _ = mg.decode_manga_list(share) if share else ([], "")
    manga_title = next(
        (m['title'] for m in manga_list if m['url'] == url),
        mg.get_filename_from_url(url)
    )

    return templates.TemplateResponse(request, "reader.html", {
        "request": request,
        "manga_url": url,
        "manga_title": manga_title,
        "share_param": share,
        "per_page": mg.IMAGES_PER_LOAD,
        "webhook1": webhook1,
        "webhook2": webhook2,
    })


# ---------------------------------------------------------------------------
# Image list partial  GET /images
# ---------------------------------------------------------------------------

@app.get("/images", response_class=HTMLResponse)
async def images_partial(
    request: Request,
    url: str = Query(...),
    offset: int = Query(default=0),
    limit: int = Query(default=0),
    webhook1: str = Query(default=""),
    webhook2: str = Query(default=""),
):
    url_hash = hashlib.md5(url.encode()).hexdigest()
    file_ext = os.path.splitext(url.split('?')[0])[-1].lower()
    archive_path = mg.get_cache_path(url) + file_ext
    extract_path = mg.get_cache_path(url) + "_extracted"

    if not os.path.exists(archive_path):
        return templates.TemplateResponse(request, "partials/download_pending.html", {
            "request": request,
            "manga_url": url,
            "offset": offset,
            "webhook1": webhook1,
            "webhook2": webhook2,
        })

    image_files, warnings = mg.extract_archive(archive_path, extract_path)
    total = len(image_files)
    page_size = limit if limit > 0 else mg.IMAGES_PER_LOAD
    batch = image_files[offset: offset + page_size]
    next_offset = offset + len(batch)
    has_more = next_offset < total

    image_items = []
    for i, path in enumerate(batch, start=offset):
        filename = os.path.basename(path)
        image_items.append({
            "src": f"/image/{url_hash}/{filename}",
            "filename": filename,
            "index": i,
            "total": total,
        })

    return templates.TemplateResponse(request, "partials/image_batch.html", {
        "request": request,
        "image_items": image_items,
        "next_offset": next_offset,
        "has_more": has_more,
        "total": total,
        "manga_url": url,
        "webhook1": webhook1,
        "webhook2": webhook2,
        "warnings": warnings,
    })


# ---------------------------------------------------------------------------
# Image binary  GET /image/{url_hash}/{filename}
# ---------------------------------------------------------------------------

@app.get("/image/{url_hash}/{filename}")
async def serve_image(url_hash: str, filename: str):
    path = os.path.join(mg.get_cache_dir(), f"{url_hash}_extracted", filename)
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="画像が見つかりません")

    loop = asyncio.get_running_loop()
    data = await loop.run_in_executor(_executor, mg.load_image_bytes, path)

    if data is None:
        raise HTTPException(status_code=500, detail="画像の読み込みに失敗しました")

    media_type = "image/png" if data[:8] == b'\x89PNG\r\n\x1a\n' else "image/jpeg"

    return Response(
        content=data,
        media_type=media_type,
        headers={"Cache-Control": "max-age=3600"},
    )


# ---------------------------------------------------------------------------
# Download + progress  GET /download/start  (SSE)
# ---------------------------------------------------------------------------

@app.get("/download/start")
async def download_start(url: str = Query(...)):
    file_ext = os.path.splitext(url.split('?')[0])[-1].lower()
    archive_path = mg.get_cache_path(url) + file_ext

    async def event_stream():
        if os.path.exists(archive_path):
            yield "data: done\n\n"
            return

        loop = asyncio.get_running_loop()
        queue: asyncio.Queue = asyncio.Queue()

        def progress_cb(p: float):
            loop.call_soon_threadsafe(queue.put_nowait, p)

        def run_download():
            success, err = mg.download_file(url, archive_path, progress_callback=progress_cb)
            if success:
                loop.call_soon_threadsafe(queue.put_nowait, "done")
            else:
                loop.call_soon_threadsafe(queue.put_nowait, f"error:{err}")

        loop.run_in_executor(_executor, run_download)

        while True:
            item = await queue.get()
            if item == "done":
                yield "data: done\n\n"
                break
            elif isinstance(item, str) and item.startswith("error:"):
                yield f"data: {item}\n\n"
                break
            else:
                yield f"data: {item:.3f}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# ---------------------------------------------------------------------------
# Thumbnail  GET /thumbnail
# ---------------------------------------------------------------------------

@app.get("/thumbnail")
async def serve_thumbnail(
    url: str = Query(...),
    index: int = Query(...),
):
    file_ext    = os.path.splitext(url.split('?')[0])[-1].lower()
    archive_path = mg.get_cache_path(url) + file_ext
    extract_path = mg.get_cache_path(url) + "_extracted"

    if not os.path.exists(archive_path):
        raise HTTPException(status_code=404, detail="アーカイブが見つかりません")

    image_files, _ = mg.extract_archive(archive_path, extract_path)
    if index < 0 or index >= len(image_files):
        raise HTTPException(status_code=404, detail="ページが見つかりません")

    loop = asyncio.get_running_loop()
    data = await loop.run_in_executor(
        _thumb_executor,
        lambda: mg.load_image_bytes(image_files[index], max_size=(80, 120)),
    )
    if data is None:
        raise HTTPException(status_code=500, detail="サムネイル生成失敗")

    media_type = "image/png" if data[:8] == b'\x89PNG\r\n\x1a\n' else "image/jpeg"
    return Response(
        content=data,
        media_type=media_type,
        headers={"Cache-Control": "max-age=86400"},
    )


# ---------------------------------------------------------------------------
# Discord send  POST /discord/send
# ---------------------------------------------------------------------------

@app.post("/discord/send", response_class=HTMLResponse)
async def discord_send(
    request: Request,
    url: Annotated[str, Form()],
    filename: Annotated[str, Form()],
    webhook1: Annotated[str, Form()] = "",
    webhook2: Annotated[str, Form()] = "",
):
    url_hash = hashlib.md5(url.encode()).hexdigest()
    image_path = os.path.join(mg.get_cache_dir(), f"{url_hash}_extracted", filename)

    webhooks = [w for w in [webhook1, webhook2] if w]
    if not webhooks:
        return HTMLResponse("<span class='status-error'>Webhookが設定されていません</span>")

    errors = mg.send_image_to_discord(image_path, webhooks, filename)
    if errors:
        msg = "<br>".join(errors)
        return HTMLResponse(f"<span class='status-error'>{msg}</span>")
    return HTMLResponse("<span class='status-ok'>✓ 送信しました</span>")


# ---------------------------------------------------------------------------
# Share URL  GET /share/url
# ---------------------------------------------------------------------------

@app.get("/share/url")
async def share_url(
    request: Request,
    share: str = Query(default=""),
    shorten: bool = Query(default=True),
):
    base = str(request.base_url).rstrip("/")
    encoded_share = urllib.parse.quote(share, safe="")
    full_url = f"{base}/?share={encoded_share}"
    result = mg.shorten_url(full_url) if shorten else full_url
    return Response(content=result, media_type="text/plain")
